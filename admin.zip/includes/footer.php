<footer>
    <p>Designed & Built by Ecstasy Solutions &copy; <?php echo date('Y'); ?></p>
</footer>

<script src="assets/js/script.js"></script>
</body>

</html>